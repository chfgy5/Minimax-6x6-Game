# To run the program for using normal minimax
	run main.py
# To run the program with by using alpha beta pruning minimax
	run main-alpha-beta-minimax.py 
	or open Jupyter Notebook file: main-alpha-beta-minimax.ipynb
